import 'package:flutter/material.dart';

import 'package:sqflite/sqflite.dart';
import 'package:path/path.dart';
import 'package:path_provider/path_provider.dart';

import 'package:sqflite_db/model.dart';


//Text(style: TextStyle(fontWeight: FontWeight.bold),)


class TaskDescription extends StatelessWidget {

  TaskDescription({required this.task});//can't have a value of 'null'

  final Task task;


  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
          title: const Text('Task Detail', textAlign: TextAlign.center,style: TextStyle(color: Colors.black, fontSize: 19.0)
        ),
          backgroundColor: MaterialColor(0xffF3F8F9,<int, Color>{}),
        ),
      body: Container(
        color: Colors.white,
        child: SafeArea(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: <Widget>[

              Expanded(
                child: Container(
                  decoration: BoxDecoration(
                    color: Theme.of(context).cardColor,
                  ),
                  child: Container(
                    width: double.infinity,
                    padding: EdgeInsets.only(
                      top: 30.0,
                      left: 30.0,
                      right: 30.0,
                      bottom: 30.0,
                    ),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: <Widget>[
                        Text(
                          'Task Title: ${task.name}',
                          style: TextStyle(fontSize: 18.0,decoration: null,),
                        ),
                        SizedBox(
                          height: 10.0,
                        ),
                        Text(
                          'Task is done: ${task.isFinished}',
                          //${task.isChecked ? 'Inc' : 'C'}omplete
                          style: TextStyle(fontSize: 18.0,decoration: null,),
                        ),
                        SizedBox(
                          height: 10.0,
                        ),
                        Text(
                          'Task Reminder: ${task.reminderDate_s != null ? task.reminderDate_s.toString() : "Not set"}',
                          style: TextStyle(fontSize: 18.0,decoration: null,),
                        ),
                        Divider(
                          color: Colors.black,
                        ),
                        /*Expanded(
                          child: Container(
                            padding: EdgeInsets.symmetric(horizontal: 20.0),
                            decoration: BoxDecoration(
                              color: Theme.of(context).cardColor,
                              borderRadius: BorderRadius.only(
                                topLeft: Radius.circular(9.0),
                                topRight: Radius.circular(9.0),
                                bottomRight: Radius.circular(9.0),
                                bottomLeft: Radius.circular(9.0),
                              ),
                            ),
                            child: TasksDescriptionList(),
                          ),
                        ),
                        Expanded(
                          child: Column(
                            mainAxisAlignment: MainAxisAlignment.end,
                            crossAxisAlignment: CrossAxisAlignment.stretch,
                            children: <Widget>[
                              TextButton(
                                child: Text(
                                  'Add Description',
                                  style: TextStyle(
                                    color: Colors.blue,
                                  ),
                                ),
                                onPressed: () {
                                  showModalBottomSheet(
                                    isScrollControlled: true,
                                    context: context,
                                    builder: (context) => SingleChildScrollView(
                                      child: Container(
                                        padding: EdgeInsets.only(
                                            bottom: MediaQuery.of(context).viewInsets.bottom),
                                        child: AddDescriptionTaskScreen(),
                                      ),
                                    ),
                                  );
                                },
                              ),
                              
                            ],
                          ),
                        ),*/
                        
                        
                
                      ],
                    ),
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
