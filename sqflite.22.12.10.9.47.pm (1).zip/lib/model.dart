import 'dart:io';

import 'package:flutter/material.dart';

import 'package:sqflite/sqflite.dart';
import 'package:path/path.dart';
import 'package:path_provider/path_provider.dart';
//import 'package:font_awesome_flutter/font_awesome_flutter.dart';
//import 'package:sqflite_db/add_task_screen.dart';

class Task {
  final int? id;// " ? " mean => may be null
  final String name;
  final String? reminderDate_s;
  bool isFinished;//will not be final mean not (constant) to use in setter

  Task({this.id, required this.name, required this.reminderDate_s, required this.isFinished});

  factory Task.fromMap(Map<String, dynamic> json) => new Task(
        id: json['id'] is int? json['id']:null,
        name: json['name'] is String? json['name']:"No name",
        reminderDate_s: json['reminderDate_s'] is String? json['reminderDate_s']:"No date",

        isFinished: json['isFinished'] is bool? json['isFinished']:false,
      );

  Map<String, dynamic> toMap() {
    return {
      'id': id,
      'name': name,
      'reminderDate_s': reminderDate_s is String? reminderDate_s:"No date",
      'isFinished': isFinished is bool? isFinished:false,
    };
  }
  
  /*
  int get get_isFinished {//getter
    return isFinished;
  }
  */

  set set_isFinished(bool is_f) {//setter
    this.isFinished = is_f;
  }
  
  
}

class DatabaseHelper {
  DatabaseHelper._privateConstructor();
  static final DatabaseHelper instance = DatabaseHelper._privateConstructor();

  static Database? _database;
  Future<Database> get database async => _database ??= await _initDatabase();

  Future<Database> _initDatabase() async {
    Directory documentsDirectory = await getApplicationDocumentsDirectory();
    String path = join(documentsDirectory.path, 'taskPlanner12.db');
    return await openDatabase(
      path,
      version: 1,
      onCreate: _onCreate,
    );
  }

  Future _onCreate(Database db, int version) async {
    await db.execute('''
      CREATE TABLE tasks_list_tbl(
          id INTEGER PRIMARY KEY AUTOINCREMENT,
          name TEXT ,
          reminderDate_s TEXT ,
          isFinished BOOLEAN 
      );
      INSERT INTO tasks_list_tbl(name,reminderDate_s,isFinished) VALUES("Task1 Name","No Date",false);
      ''');
  }

  Future<List<Task>> getTask_list2() async {
    Database db = await instance.database;
    var tasks_list_tbl = await db.query('tasks_list_tbl', where: 'isFinished = ?', whereArgs: [false], orderBy: 'id asc');
    List<Task> taskList = tasks_list_tbl.isNotEmpty
        ? tasks_list_tbl.map((c) => Task.fromMap(c)).toList()
        : [];
    return taskList;
  }
  
  Future<List<Task>> getTask_list2_finish() async {
    Database db = await instance.database;
    var tasks_list_tbl = await db.query('tasks_list_tbl', where: 'isFinished = ?', whereArgs: [true], orderBy: 'id asc');
    List<Task> taskList = tasks_list_tbl.isNotEmpty
        ? tasks_list_tbl.map((c) => Task.fromMap(c)).toList()
        : [];
    return taskList;
  }

  Future<int> add(Task task) async {
    Database db = await instance.database;
    //print (task.name);
    return await db.insert('tasks_list_tbl', task.toMap());
  }

  Future<int> remove(int id) async {
    Database db = await instance.database;
    return await db.delete('tasks_list_tbl', where: 'id = ?', whereArgs: [id]);
  }
  
  Future<int> finished(Task task) async {//toggle
    Database db = await instance.database;
    
      //db.execute("DELETE FROM tasks_list_tbl WHERE id="+task.id.toString()+" ;");
      //db.delete('tasks_list_tbl', where: 'id = ?', whereArgs: [task.id]);
      task.set_isFinished=true;
      return await db.update('tasks_list_tbl', task.toMap(),where: "id = ?", whereArgs: [task.id]);
      
      //return await db.execute("UPDATE TABLE tasks_list_tbl SET isFinished=NOT isFinished WHERE id="+task.id.toString()+" ;");
      //return await db.update('tasks_list_tbl', task.toMap(),where: "id = ?", whereArgs: [task.id]);
  }
  


  Future<int> update(Task task) async {
    Database db = await instance.database;
    return await db.update('tasks_list_tbl', task.toMap(),
        where: "id = ?", whereArgs: [task.id]);
  }
}

