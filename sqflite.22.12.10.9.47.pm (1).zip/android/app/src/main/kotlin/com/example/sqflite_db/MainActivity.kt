package com.example.sqflite_db

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
