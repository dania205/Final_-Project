import 'dart:io';

import 'package:flutter/material.dart';

import 'package:sqflite/sqflite.dart';
import 'package:path/path.dart';
import 'package:path_provider/path_provider.dart';

import 'package:sqflite_db/model.dart';
import 'package:sqflite_db/task_description.dart';


void main() => runApp(MaterialApp(home:SqliteApp()));


class SqliteApp extends StatefulWidget {
  const SqliteApp({Key? key}) : super(key: key);

  @override
  _SqliteAppState createState() => _SqliteAppState();
}

class _SqliteAppState extends State<SqliteApp> {
  int? selectedId;
  final textController = TextEditingController();

  String currTask = '';
  bool remindMe = false;
  DateTime? reminderDate;
  TimeOfDay? reminderTime;
  int id =0;

  
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      home: Scaffold(
        drawer: Drawer(
        child: SafeArea(
          child: ListView(
            
            padding: EdgeInsets.only(top: 5.0),
            children: <Widget>[
              SizedBox(
              height: 77.0,
              child:DrawerHeader(
                          decoration: BoxDecoration(
                              /*gradient: LinearGradient(
                                  colors: <Color> [Colors.black, Colors.white]
                              )*/
                              color:Colors.white,
                          ),
                          child:Column(
                            children: [
                              Row(
                                children: [
                                  Text(
                                    'Baraa Saleh ',
                                    style: TextStyle(
                                        fontSize: 16,
                                        fontWeight: FontWeight.bold,
                                        color: Colors.black),
                                  ),
                                  IconButton(icon: Icon(Icons.search), onPressed: () {  }, ),
                                  IconButton(icon: Icon(Icons.notifications), onPressed: () {  },),
                                  IconButton(icon: Icon(Icons.settings), onPressed: () {  },),
                                ],
                              )
                            ],
                          )

                      ),
                    ),
              ListTile(
                leading: Icon(Icons.today),
                title: Text('Today'),
                onTap: () {
                  //Navigator.pushNamed(context, AppInfoScreen.id);
                },
              ),
              ListTile(
                  leading: Icon(Icons.inbox),
                  title: Text('Inbox'),
                  onTap: () {
                    //Navigator.pushNamed(context, InstructionsScreen.id);
                  }),
              ListTile(
                leading: Icon(Icons.hail),
                title: Text('Welcome'),
                onTap: () {
                  //Navigator.pushNamed(context, SettingsScreen.id);
                },
              ),
              ListTile(
                leading: Icon(Icons.work),
                title: Text('Work'),
                onTap: () {
                  //Navigator.pushNamed(context, SettingsScreen.id);
                },
              ),
              ListTile(
                leading: Icon(Icons.home),
                title: Text('Personal'),
                onTap: () {
                  //Navigator.pushNamed(context, SettingsScreen.id);
                },
              ),
              ListTile(
                leading: Icon(Icons.shop),
                title: Text('Shopping'),
                onTap: () {
                  //Navigator.pushNamed(context, SettingsScreen.id);
                },
              ),
              ListTile(
                leading: Icon(Icons.list_alt_outlined),
                title: Text('Wish List'),
                onTap: () {
                  //Navigator.pushNamed(context, SettingsScreen.id);
                },
              ),
              ListTile(
                leading: Icon(Icons.cake),
                title: Text('Birthday'),
                onTap: () {
                  //Navigator.pushNamed(context, SettingsScreen.id);
                },
              )
            ],
          ),
        ),
      ),
      backgroundColor: MaterialColor(0xffF3F8F9,<int, Color>{}),
      floatingActionButton: FloatingActionButton(
        onPressed: () {
          showModalBottomSheet(
            isScrollControlled: true,
            context: context,
            builder: (context) => SingleChildScrollView(
              child: Container(
                padding: EdgeInsets.only(
                    bottom: MediaQuery.of(context).viewInsets.bottom),
                child: Container(
                      color: Colors.transparent,
                      child: Container(
                        decoration: BoxDecoration(
                          color: Theme.of(context).cardColor,
                          borderRadius: BorderRadius.only(
                            topRight: Radius.circular(30.0),
                            topLeft: Radius.circular(30.0),
                          ),
                        ),
                        child: Padding(
                          padding: EdgeInsets.symmetric(horizontal: 30.0, vertical: 20.0),
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.stretch,
                            children: <Widget>[
                              Text(
                                'Add Task',
                                textAlign: TextAlign.center,
                                style: TextStyle(
                                  fontSize: 30.0,
                                  fontWeight: FontWeight.w500,
                                ),
                              ),
                              TextField(
                                controller: textController,
                                autofocus: true,
                                textAlign: TextAlign.center,
                                style: TextStyle(
                                  fontSize: 16.0,
                                ),
                                textCapitalization: TextCapitalization.sentences,
                                onChanged: (newVal) {
                                  currTask = newVal;
                                },
                                decoration: InputDecoration(
                                  contentPadding: EdgeInsets.all(2.0),
                                  border: UnderlineInputBorder(
                                    borderSide: BorderSide(
                                    ),
                                  ),
                                ),
                              ),
                              SizedBox(
                                height: 10.0,
                              ),
                              SwitchListTile(
                                value: remindMe,
                                title: Text('Reminder'),
                                onChanged: (newValue) async {
                                  if (newValue) {
                                    reminderDate = await showDatePicker(
                                      context: context,
                                      initialDate: DateTime.now(),
                                      firstDate: DateTime.now(),
                                      lastDate: DateTime(DateTime.now().year + 2),
                                    );

                                    if (reminderDate == null) {
                                      return;
                                    }

                                    reminderTime =
                                        await showTimePicker(context: context, initialTime: TimeOfDay.now());

                                    if (reminderDate != null && reminderTime != null) {
                                      remindMe = newValue;
                                    }
                                  } else {
                                    reminderDate = null;
                                    reminderTime = null;
                                    remindMe = newValue;
                                  }

                                  print(reminderTime);
                                  print(reminderDate);

                                  setState(() {});
                                },
                                subtitle: Text('Remind me for this task'),
                              ),
                              SizedBox(
                                height: 10.0,
                              ),
                              Container(
                                  //child: remindMe? Text('Reminder set at: ' +DateTime(reminderDate.year, reminderDate.month, reminderDate.day,reminderTime.hour, reminderTime.minute).toString()): null), 
                                  child: remindMe? Text('Reminder set at: '+DateTime(reminderDate!.year, reminderDate!.month, reminderDate!.day,reminderTime!.hour, reminderTime!.minute).toString()) : null), 
                                    
                                  
                              
                                  
                              SizedBox(
                                height: remindMe ? 10.0 : 0.0,
                              ),
                              TextButton(
                                onPressed: () 
                                    async {
                                         await DatabaseHelper.instance.add(
                                                Task(name: textController.text, reminderDate_s:DateTime(reminderDate!.year, reminderDate!.month, reminderDate!.day,reminderTime!.hour, reminderTime!.minute).toString(), isFinished: false ));
                                                //Task(name: currTask, reminderDate:DateTime(reminderDate!.year, reminderDate!.month, reminderDate!.day,reminderTime!.hour, reminderTime!.minute), isFinished: false ));

                                              
                                        setState(() {
                                          textController.clear();
                                          selectedId = null;
                                        });
                                        Navigator.pop(context);
                                        
                                  
                                      },
                                child: Text(
                                  'ADD',
                                  style: TextStyle(
                                    color: Colors.blue,
                                  ),
                                ),
                              )
                            ],
                          ),
                        ),
                      ),
                    ),
              ),
            ),
          );
        },
        backgroundColor: Colors.lightBlueAccent,
        child: Icon(Icons.add),
      ),
      bottomNavigationBar: BottomNavigationBar(items: [
          BottomNavigationBarItem(label: "", icon: Icon(Icons.check_box)),
          BottomNavigationBarItem(label: "", icon: Icon(Icons.calendar_today_outlined)),
          BottomNavigationBarItem(label: "", icon: Icon(Icons.settings)),
        ],),
      appBar: AppBar(
          title: const Text('Inbox', textAlign: TextAlign.center,style: TextStyle(color: Colors.black, fontSize: 19.0)
        ),
          backgroundColor: MaterialColor(0xffF3F8F9,<int, Color>{}),
        ),
        
        /*appBar: AppBar(
          title: TextField(
            controller: textController,
          ),
        ),*/

                
        body: Column(
              children: <Widget>[
              
              Flexible(
              child: Container(
              child:FutureBuilder<List<Task>>(
              future: DatabaseHelper.instance.getTask_list2(),
              builder: (BuildContext context,
                  AsyncSnapshot<List<Task>> snapshot) {
                if (!snapshot.hasData) {
                  return Center(child: Text('Loading...'));
                }
                return snapshot.data!.isEmpty
                    ? Center(child: Text('No Task in List'))
                    : ListView(
                        children: snapshot.data!.map((task) {
                          return Center(
                            child: Card(
                              color: selectedId == task.id
                                  ? Colors.white70
                                  : Colors.white,
                              child: ListTile(
                                title: Text(task.name),
                                trailing: Checkbox(
                                    activeColor: MaterialColor(0xff9D9D9D,<int, Color>{}),
                                    value: false,
                                    onChanged: (bool? value) {
                                      setState(() {
                                        DatabaseHelper.instance.finished(task);
                                      });
                                  },
                                  ),
                                onTap: () {
                                  Navigator.push(context, MaterialPageRoute(builder: (context) {
                                    return TaskDescription(
                                      task: task,
                                    );
                                  }));
                                },
                              ),
                            ),
                          );
                        }).toList(),
                      );
              }),
              ),
              ),
  
              
              Container(
                  padding: EdgeInsets.only(
                    top: 3.0,
                    left: 3.0,
                    right: 3.0,
                    bottom: 3.0,
                  ),
                  child:Text("COMPLETED",style: TextStyle(fontWeight: FontWeight.bold,fontSize: 19,color:Colors.grey),),
                ),
              
              
              Flexible(
              child: Container(
              child:FutureBuilder<List<Task>>(
              future: DatabaseHelper.instance.getTask_list2_finish(),
              builder: (BuildContext context,
                  AsyncSnapshot<List<Task>> snapshot) {
                if (!snapshot.hasData) {
                  return Center(child: Text('Loading...'));
                }
                return snapshot.data!.isEmpty
                    ? Center(child: Text('No Task Finish'))
                    : ListView(
                        children: snapshot.data!.map((task) {
                          return Center(
                            child: Card(
                              color: selectedId == task.id
                                  ? Colors.white70
                                  : Colors.white,
                              child: ListTile(
                                title: Text(task.name),
                                trailing: Checkbox(
                                    activeColor: MaterialColor(0xff9D9D9D,<int, Color>{}),
                                    value: true,
                                    onChanged: (bool? value) {
                                      setState(() {
                                        DatabaseHelper.instance.remove(task.id!);
                                      });
                                  },
                                  ),
                                
                                onTap: () {
                                  Navigator.push(context, MaterialPageRoute(builder: (context) {
                                    return TaskDescription(
                                      task: task,
                                    );
                                  }));
                                },
                              ),
                            ),
                          );
                        }).toList(),
                      );
              }),
              
              ),
              ),
              
              
              
              ],
        ),
        

      ),
    );
  }
}


